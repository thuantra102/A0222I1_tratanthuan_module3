package bussiness;

import common.BaseCRUD;
import model.Category;

public interface CategoryManager extends BaseCRUD<Category> {
}
