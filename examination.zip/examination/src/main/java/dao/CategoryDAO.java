package dao;

import common.BaseCRUD;
import model.Category;

public interface CategoryDAO extends BaseCRUD<Category> {
}
