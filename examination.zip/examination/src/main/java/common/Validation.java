package common;

public class Validation {
}
